#include <iostream>
#include <unistd.h>
#include "shared_memory_base.h"

using namespace std;

int main()
{
    int remainder;
    shared_memory_base comm;
    comm.init();

    comm.data->analog_input[0] =0;
    comm.data->analog_input[8] =0;

    for (int i=0;i<10;i++){
        while( comm.data->go_flag_first_loop != 1); // wait until second program set it to 1
        comm.data->analog_input[0] = i;
        //cout << "Write log: "; 
        //cin.getline(comm.data->logBuffer,STRINGBUFSIZE);

#if 0        
        //cin >> std::ws; // clear previous line
        remainder = comm.data->analog_input[0] % 2;
        if (remainder ==1) // odd number, program 1 write to command buffer
        {
            cout << "Write command: "; 
            cin.getline(comm.data->commandBuffer,STRINGBUFSIZE);
        }
        else
        {   // even number, program 1 write to log buffer
            cout << "Write log: "; 
            cin.getline(comm.data->logBuffer,STRINGBUFSIZE);
        }
#endif

        cout << "Second Program wrote: ai[8]: " << comm.data->analog_input[8] << endl;

#if 1
        // Check if program 2 write either odd or even number
        remainder = comm.data->analog_input[8] % 2;
        if (remainder ==0) // even number, program 2 write to command buffer
        {
            cout << "Second Program wrote command buffer: " << comm.data->commandBuffer << endl;
            cout << "Write log: "; 
            cin.getline(comm.data->logBuffer,STRINGBUFSIZE); // response with log            
        }
        else
        {   // odd number, program 2 write to log
            cout << "Second Program wrote log buffer: " << comm.data->logBuffer << endl;
            cout << "Write command: "; 
            cin.getline(comm.data->commandBuffer,STRINGBUFSIZE);  // response with command
        }   
#endif

        comm.data->go_flag_second_loop = 1;
        sleep(1);
    }

    cout << "end of the loop!" << endl;
    comm.detach_shared_memory();
    return 0;
}
