#include <iostream>
#include "shared_memory_base.h"

using namespace std;

int main()
{
    int remainder;

    shared_memory_base comm;
    comm.init();

    comm.data->analog_input[0] =0;
    comm.data->analog_input[8] =0;
    comm.data->go_flag_first_loop = 1;

    for (int i=0;i<10;i++){
        while( comm.data->go_flag_second_loop != 1);  // wait until first program set it to 1
        comm.data->analog_input[8] = 1000-i;
        //cout << "Write command: "; 
        //cin.getline(comm.data->commandBuffer,STRINGBUFSIZE);
        
#if 0
        //cin >> std::ws; // clear previous line
        remainder = comm.data->analog_input[8] % 2;
        if (remainder ==0) // even number, program 2 write to command buffer
        {
            cout << "Write command: "; 
            cin.getline(comm.data->commandBuffer,STRINGBUFSIZE);
        }
        else
        {   // odd number, program 2 write to log buffer
            cout << "Write log: "; 
            cin.getline(comm.data->logBuffer,STRINGBUFSIZE);
        }
#endif
        cout << "First Program wrote: ai[0]: " << comm.data->analog_input[0] << endl; 
#if 1       
        // Check if program 1 write either odd or even number
        remainder = comm.data->analog_input[0] % 2;
        if (remainder ==1) // odd number, program 1 write to command buffer
        {
            cout << "Second Program wrote command buffer: " << comm.data->commandBuffer << endl;
            //comm.data->logBuffer[0] = "log";  // response with log            
        }
        else
        {   // even number, program 1 write to log
            cout << "Second Program wrote log buffer: " << comm.data->logBuffer << endl;
            //comm.data->commandBuffer[0] = "Command";  // response with command
        }
#endif
        comm.data->go_flag_second_loop = 0;  // clear this so program 1 will set it to 1
    }

    cout << "end of the loop!" << endl;
    comm.detach_shared_memory();
    return 0;
}
